'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import Icon from '@/components/Icon';
import { Page } from '@/components/ui';
import { useApp } from '@/components/AppProvider';
import { ART } from '@/components/art';
import { sb } from '@/lib/supabase';

export default function HomePage() {
  const router = useRouter();
  const { settings, setBookFilter, ready } = useApp();
  const [counts, setCounts] = useState({ books: null, comps: null });
  const ann = String(settings.announcement || '').trim();

  useEffect(() => {
    if (!ready || !sb) return;
    let alive = true;
    (async () => {
      try {
        const nowIso = new Date().toISOString();
        const [b, c] = await Promise.all([
          sb.from('books').select('id', { count: 'exact', head: true }),
          sb.from('competitions').select('id', { count: 'exact', head: true }).lte('starts_at', nowIso).gte('ends_at', nowIso)
        ]);
        if (alive) setCounts({ books: b.error ? null : b.count, comps: c.error ? null : c.count });
      } catch (e) { console.error(e); }
    })();
    return () => { alive = false; };
  }, [ready]);

  const search = e => {
    e.preventDefault();
    const q = String(new FormData(e.currentTarget).get('q') || '').trim();
    setBookFilter(f => ({ ...f, q, mode: 'all' }));
    router.push('/books');
  };

  const tiles = [
    { cls: 't1', href: '/competitions', art: ART.comp, h: 'مسابقات المكتبة', p: 'شارك في مسابقات المكتبة وتابع المسابقات السابقة.',
      meta: counts.comps == null ? ' ' : counts.comps ? `${counts.comps} مسابقة جارية الآن` : 'لا توجد مسابقة جارية حاليًا' },
    { cls: 't2', href: '/books', art: ART.books, h: 'الكتب', p: 'تصفّح الكتب ومعاينة ملفاتها، وأضف ما يعجبك إلى المفضلة.',
      meta: counts.books == null ? ' ' : `${counts.books} كتاب في المكتبة` },
    { cls: 't3', href: '/request', art: ART.req, h: 'طلب كتاب', p: 'لم تجد الكتاب الذي تبحث عنه؟ قدّم طلبًا وتابع حالته.' },
    { cls: 't4', href: '/concerns', art: ART.voice, h: 'ملاحظات واقتراحات', p: 'مساحة خاصة وآمنة لإرسال مشكلة أو اقتراح.' }
  ];

  return (
    <Page>
      <section className="hero">
        <h1>{settings.site_name}</h1>
        <p>تصفّح مقتنيات المكتبة، وشارك في مسابقاتها، وقدّم طلبًا بما تحتاج إليه من كتب.</p>
        <form className="hero-search" role="search" onSubmit={search}>
          <input name="q" type="search" maxLength={100} placeholder="ابحث عن كتاب أو مؤلف أو مادة…" aria-label="بحث في الكتب" />
          <button className="btn" type="submit"><Icon n="search" s={18} /> بحث</button>
        </form>
        {ann && <div className="announce"><Icon n="chat" s={18} /> {ann}</div>}
      </section>
      <section className="tiles" aria-label="الأقسام الرئيسية">
        {tiles.map(t => (
          <Link key={t.href} className={'tile ' + t.cls} href={t.href}>
            <div className="art" dangerouslySetInnerHTML={{ __html: t.art }} />
            <span className="go" aria-hidden="true"><Icon n="arrow" s={24} /></span>
            <div className="txt"><h3>{t.h}</h3><p>{t.p}</p>{t.meta !== undefined && <div className="meta">{t.meta}</div>}</div>
          </Link>
        ))}
      </section>
    </Page>
  );
}
